from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey, Float, Numeric
from sqlalchemy.orm import declarative_base
import logging
from datetime import datetime

serverName = get_vault_secret('db-host')
databaseName = get_vault_secret('db-name')
userName = get_vault_secret("db-username")
password = get_vault_secret("db-password")
schemaName = get_vault_secret("db-schema")
encoded_password = quote_plus(password)

class OrmAlchemy:

    def conn(self):
        engines = create_engine(f'postgresql+psycopg2://{userName}:{encoded_password}@{serverName}/{databaseName}?options=-csearch_path={schemaName}')
        if engines.connect() is not None:
            logger.info("db connection established()")
            return engines
        else:
            logger.error("db connection failed")
            return None


Base = declarative_base()
engine = OrmAlchemy.conn(self=0)

class Users(Base):
    __tablename__ = 'users'
    user_id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    user_name  = Column(String(500), nullable=False)
    user_mail = Column(String(500), nullable=False)
    role = Column(Integer, ForeignKey('roles.id'))
    created_timestamp = Column(DateTime, default=datetime.now, nullable=False)
    modified_timestamp = Column(DateTime, onupdate=datetime.now)
    def __repr__(self):
        return str({ "user_id": self.user_id,
                     "user_name": self.user_name,
                     "user_mail": self.user_mail,
                     "role": self.role,
                     "created_timestamp": self.created_timestamp,
                     "modified_timestamp": self.modified_timestamp
        })

from DB.entity import engine, Users

from sqlalchemy import func, case, and_, insert, text, null, literal
from sqlalchemy.orm import sessionmaker
Session = sessionmaker(bind=engine)


def queryset_to_dict(query_result):
    try:
        query_columns = query_result.statement.columns.keys()
        res = [list(ele) for ele in query_result.all()]
        dict_list = [dict(zip(query_columns, lst)) for lst in res]
        return dict_list
    except Exception as e:
        print(e)
        query_columns = query_result.keys()
        res = [list(ele) for ele in query_result.all()]
        dict_list = [dict(zip(query_columns, lst)) for lst in res]
        return dict_list


class UserFlow:
    def getalluser(self):
        try:
            sessions = Session()
            query = sessions.query(Users.user_id, Users.user_mail, Users.role)
            return queryset_to_dict(query)
        except Exception as e:
            return "Exception occurred"
        finally:
            sessions.close()

    def getuser(self, user_id):
        try:
            sessions = Session()
            query = sessions.query(Users.user_id, Users.user_mail, Users.role).filter(Users.user_id == user_id)
            return queryset_to_dict(query)
        except Exception as e:
            return "Exception occurred"
        finally:
            sessions.close()